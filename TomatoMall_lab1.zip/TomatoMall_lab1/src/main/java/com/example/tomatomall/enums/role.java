package com.example.tomatomall.enums;

public enum role {
    CUSTOMER, STAFF, SHOPKEEPER, ADMINISTRATOR
}
